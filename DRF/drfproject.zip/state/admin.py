from django.contrib import admin
from state.models import *

# Register your models here.
admin.site.register(StateEdit)
