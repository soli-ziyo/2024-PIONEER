from django.contrib import admin
from home.models import *

# Register your models here.

admin.site.register(HashTag)
admin.site.register(WeekHashTag)
#admin.site.register(Home)