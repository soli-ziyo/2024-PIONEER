from django.apps import AppConfig


class InterestConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'interest'
