from django.contrib import admin
from interest.models import *

# Register your models here.
admin.site.register(Interest)